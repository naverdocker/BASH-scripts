#!/bin/bash

apt update

sudo apt-get install fontconfig openjdk-11-jre -y

wget https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.65/bin/apache-tomcat-9.0.65.tar.gz

tar -zxvf ./apache-tomcat-9.0.65.tar.gz

mv ./apache-tomcat-9.0.65 /opt/apache-tomcat

/opt/apache-tomcat/bin/startup.sh

cp /root/tomcat/index.html /opt/apache-tomcat/webapps/ROOT/index.html

rm -rf /root/tomcat/apache-tomcat*
